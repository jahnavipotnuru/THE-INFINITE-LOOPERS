export interface User {
  id: string
  name: string
  email?: string
  phone?: string
  userType: "buyer" | "seller"
  createdAt: string
}

export interface Seller extends User {
  shopName: string
  shopAddress: string
  shopLocation: string
  shopImage?: string
}

export interface Product {
  id: string
  sellerId: string
  sellerName: string
  shopName: string
  productCode: string
  productName: string
  productImage: string
  category: string
  subcategory: string
  price: number
  description: string
  createdAt: string
}

export interface SavedProduct {
  buyerId: string
  productId: string
  savedAt: string
}

export interface AuthState {
  user: User | null
  isAuthenticated: boolean
}
