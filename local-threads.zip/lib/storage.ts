import type { User, Product, SavedProduct } from "./types"

const USERS_KEY = "local_threads_users"
const PRODUCTS_KEY = "local_threads_products"
const SAVED_PRODUCTS_KEY = "local_threads_saved"
const CURRENT_USER_KEY = "local_threads_current_user"

export const storage = {
  // User operations
  getUsers: (): User[] => {
    const data = localStorage.getItem(USERS_KEY)
    return data ? JSON.parse(data) : []
  },

  saveUser: (user: User) => {
    const users = storage.getUsers()
    const existingIndex = users.findIndex((u) => u.id === user.id)
    if (existingIndex >= 0) {
      users[existingIndex] = user
    } else {
      users.push(user)
    }
    localStorage.setItem(USERS_KEY, JSON.stringify(users))
  },

  getUserByEmail: (email: string): User | undefined => {
    return storage.getUsers().find((u) => u.email?.toLowerCase() === email.toLowerCase())
  },

  getUserByPhone: (phone: string): User | undefined => {
    return storage.getUsers().find((u) => u.phone === phone)
  },

  // Product operations
  getProducts: (): Product[] => {
    const data = localStorage.getItem(PRODUCTS_KEY)
    return data ? JSON.parse(data) : []
  },

  saveProduct: (product: Product) => {
    const products = storage.getProducts()
    products.push(product)
    localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products))
  },

  getProductsBySeller: (sellerId: string): Product[] => {
    return storage.getProducts().filter((p) => p.sellerId === sellerId)
  },

  deleteProduct: (productId: string) => {
    const products = storage.getProducts()
    const filtered = products.filter((p) => p.id !== productId)
    localStorage.setItem(PRODUCTS_KEY, JSON.stringify(filtered))
  },

  getProductById: (productId: string): Product | undefined => {
    return storage.getProducts().find((p) => p.id === productId)
  },

  // Saved products operations
  getSavedProducts: (buyerId: string): Product[] => {
    const data = localStorage.getItem(SAVED_PRODUCTS_KEY)
    const saved: SavedProduct[] = data ? JSON.parse(data) : []
    const savedProductIds = saved.filter((s) => s.buyerId === buyerId).map((s) => s.productId)
    return storage.getProducts().filter((p) => savedProductIds.includes(p.id))
  },

  saveProductForBuyer: (buyerId: string, productId: string) => {
    const data = localStorage.getItem(SAVED_PRODUCTS_KEY)
    const saved: SavedProduct[] = data ? JSON.parse(data) : []
    if (!saved.find((s) => s.buyerId === buyerId && s.productId === productId)) {
      saved.push({ buyerId, productId, savedAt: new Date().toISOString() })
      localStorage.setItem(SAVED_PRODUCTS_KEY, JSON.stringify(saved))
    }
  },

  removeSavedProduct: (buyerId: string, productId: string) => {
    const data = localStorage.getItem(SAVED_PRODUCTS_KEY)
    const saved: SavedProduct[] = data ? JSON.parse(data) : []
    const filtered = saved.filter((s) => !(s.buyerId === buyerId && s.productId === productId))
    localStorage.setItem(SAVED_PRODUCTS_KEY, JSON.stringify(filtered))
  },

  isProductSaved: (buyerId: string, productId: string): boolean => {
    const data = localStorage.getItem(SAVED_PRODUCTS_KEY)
    const saved: SavedProduct[] = data ? JSON.parse(data) : []
    return saved.some((s) => s.buyerId === buyerId && s.productId === productId)
  },

  // Current user
  setCurrentUser: (user: User | null) => {
    if (user) {
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user))
    } else {
      localStorage.removeItem(CURRENT_USER_KEY)
    }
  },

  getCurrentUser: (): User | null => {
    const data = localStorage.getItem(CURRENT_USER_KEY)
    return data ? JSON.parse(data) : null
  },
}
