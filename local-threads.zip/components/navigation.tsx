"use client"

import Link from "next/link"
import { useRouter } from "next/navigation"
import { storage } from "@/lib/storage"
import { useState } from "react"

export default function Navigation() {
  const router = useRouter()
  const currentUser = storage.getCurrentUser()
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const handleLogout = () => {
    storage.setCurrentUser(null)
    router.push("/")
  }

  return (
    <nav className="bg-black text-white sticky top-0 z-50 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center gap-2">
            <div className="text-2xl font-bold">LOCAL THREADS</div>
          </Link>

          <div className="hidden md:flex items-center gap-8">
            {!currentUser ? (
              <>
                <Link href="/buyer-login" className="hover:text-gray-300 transition">
                  Buyer Login
                </Link>
                <Link href="/seller-login" className="hover:text-gray-300 transition">
                  Seller Login
                </Link>
              </>
            ) : (
              <>
                <span className="text-sm text-gray-300">
                  {currentUser.name} ({currentUser.userType})
                </span>
                {currentUser.userType === "buyer" ? (
                  <Link href="/buyer-dashboard" className="hover:text-gray-300 transition">
                    Dashboard
                  </Link>
                ) : (
                  <Link href="/seller-dashboard" className="hover:text-gray-300 transition">
                    Dashboard
                  </Link>
                )}
                <button
                  onClick={handleLogout}
                  className="bg-white text-black px-4 py-2 rounded hover:bg-gray-200 transition"
                >
                  Logout
                </button>
              </>
            )}
          </div>

          <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            ☰
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden pb-4 space-y-2">
            {!currentUser ? (
              <>
                <Link href="/buyer-login" className="block hover:text-gray-300">
                  Buyer Login
                </Link>
                <Link href="/seller-login" className="block hover:text-gray-300">
                  Seller Login
                </Link>
              </>
            ) : (
              <>
                <span className="block text-sm text-gray-300">
                  {currentUser.name} ({currentUser.userType})
                </span>
                {currentUser.userType === "buyer" ? (
                  <Link href="/buyer-dashboard" className="block hover:text-gray-300">
                    Dashboard
                  </Link>
                ) : (
                  <Link href="/seller-dashboard" className="block hover:text-gray-300">
                    Dashboard
                  </Link>
                )}
                <button
                  onClick={handleLogout}
                  className="block w-full text-left bg-white text-black px-4 py-2 rounded hover:bg-gray-200"
                >
                  Logout
                </button>
              </>
            )}
          </div>
        )}
      </div>
    </nav>
  )
}
