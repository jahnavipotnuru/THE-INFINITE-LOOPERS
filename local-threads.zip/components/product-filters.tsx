"use client"

import type React from "react"

import { useState } from "react"

interface ProductFiltersProps {
  onFilterChange: (filters: {
    category: string
    subcategory: string
    priceRange: [number, number]
    searchTerm: string
  }) => void
}

const categories = [
  "Top Wear",
  "Bottom Wear",
  "Ethnic Wear",
  "Kids Wear",
  "Dresses",
  "Outerwear",
  "Activewear",
  "Accessories",
]

const subcategories: Record<string, string[]> = {
  "Top Wear": ["T-Shirts", "Shirts", "Tops", "Blouses", "Crop Tops", "Hoodies", "Sweaters", "Cardigans"],
  "Bottom Wear": ["Jeans", "Trousers", "Skirts", "Shorts", "Leggings", "Capris", "Palazzo Pants", "Joggers"],
  "Ethnic Wear": ["Sarees", "Lehengas", "Kurtis", "Kurtas", "Salwar Kameez", "Dupattas", "Anarkali", "Sharara"],
  "Kids Wear": ["Dresses", "T-Shirts", "Shorts", "Sets", "Frocks", "Ethnic Wear", "Jumpsuits", "Rompers"],
  Dresses: [
    "Casual Dresses",
    "Formal Dresses",
    "Party Dresses",
    "Maxi Dresses",
    "Midi Dresses",
    "Bodycon Dresses",
    "A-Line Dresses",
    "Wrap Dresses",
  ],
  Outerwear: ["Jackets", "Blazers", "Coats", "Shrugs", "Ponchos", "Capes", "Vests", "Waistcoats"],
  Activewear: ["Gym Wear", "Yoga Wear", "Sports Bra", "Leggings", "Shorts", "Track Suits", "Swimwear", "Athleisure"],
  Accessories: ["Scarves", "Belts", "Shawls", "Stoles", "Wraps", "Jewelry", "Bags", "Footwear"],
}

export default function ProductFilters({ onFilterChange }: ProductFiltersProps) {
  const [filters, setFilters] = useState({
    category: "",
    subcategory: "",
    priceRange: [0, 5000] as [number, number],
    searchTerm: "",
  })

  const handleCategoryChange = (category: string) => {
    const newFilters = {
      ...filters,
      category,
      subcategory: "",
    }
    setFilters(newFilters)
    onFilterChange(newFilters)
  }

  const handleSubcategoryChange = (subcategory: string) => {
    const newFilters = { ...filters, subcategory }
    setFilters(newFilters)
    onFilterChange(newFilters)
  }

  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newFilters = {
      ...filters,
      priceRange: [0, Number.parseInt(e.target.value)] as [number, number],
    }
    setFilters(newFilters)
    onFilterChange(newFilters)
  }

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newFilters = { ...filters, searchTerm: e.target.value }
    setFilters(newFilters)
    onFilterChange(newFilters)
  }

  return (
    <div className="bg-gray-50 p-6 rounded-lg sticky top-20">
      <h2 className="text-xl font-bold mb-6">Filters</h2>

      <div className="mb-6">
        <label className="block text-sm font-medium mb-2">Search</label>
        <input
          type="text"
          value={filters.searchTerm}
          onChange={handleSearchChange}
          className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-black"
          placeholder="Search products..."
        />
      </div>

      <div className="mb-6">
        <h3 className="font-semibold mb-3">Category</h3>
        <div className="space-y-2 max-h-64 overflow-y-auto">
          <label className="flex items-center">
            <input
              type="radio"
              name="category"
              value=""
              checked={filters.category === ""}
              onChange={() => handleCategoryChange("")}
              className="mr-2"
            />
            <span className="text-sm">All Categories</span>
          </label>
          {categories.map((cat) => (
            <label key={cat} className="flex items-center">
              <input
                type="radio"
                name="category"
                value={cat}
                checked={filters.category === cat}
                onChange={() => handleCategoryChange(cat)}
                className="mr-2"
              />
              <span className="text-sm">{cat}</span>
            </label>
          ))}
        </div>
      </div>

      {filters.category && (
        <div className="mb-6">
          <h3 className="font-semibold mb-3">Subcategory</h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            <label className="flex items-center">
              <input
                type="radio"
                name="subcategory"
                value=""
                checked={filters.subcategory === ""}
                onChange={() => handleSubcategoryChange("")}
                className="mr-2"
              />
              <span className="text-sm">All</span>
            </label>
            {subcategories[filters.category]?.map((subcat) => (
              <label key={subcat} className="flex items-center">
                <input
                  type="radio"
                  name="subcategory"
                  value={subcat}
                  checked={filters.subcategory === subcat}
                  onChange={() => handleSubcategoryChange(subcat)}
                  className="mr-2"
                />
                <span className="text-sm">{subcat}</span>
              </label>
            ))}
          </div>
        </div>
      )}

      <div className="mb-6">
        <h3 className="font-semibold mb-3">Price Range</h3>
        <div className="space-y-2">
          <input
            type="range"
            min="0"
            max="5000"
            value={filters.priceRange[1]}
            onChange={handlePriceChange}
            className="w-full"
          />
          <div className="text-sm text-gray-600">₹0 - ₹{filters.priceRange[1]}</div>
        </div>
      </div>
    </div>
  )
}
