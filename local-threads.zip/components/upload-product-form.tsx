"use client"

import type React from "react"

import { useState } from "react"
import { storage } from "@/lib/storage"
import type { Seller, Product } from "@/lib/types"

interface UploadProductFormProps {
  seller: Seller
  onProductAdded: () => void
}

const categories = ["Top Wear", "Bottom Wear", "Ethnic Wear", "Kids Wear"]

const subcategories: Record<string, string[]> = {
  "Top Wear": ["T-Shirts", "Shirts", "Tops", "Blouses"],
  "Bottom Wear": ["Jeans", "Trousers", "Skirts", "Shorts"],
  "Ethnic Wear": ["Sarees", "Lehengas", "Kurtis", "Kurtas"],
  "Kids Wear": ["Dresses", "T-Shirts", "Shorts", "Sets"],
}

export default function UploadProductForm({ seller, onProductAdded }: UploadProductFormProps) {
  const [formData, setFormData] = useState({
    productName: "",
    productCode: "",
    category: "",
    subcategory: "",
    price: "",
    description: "",
    productImage: "",
  })
  const [error, setError] = useState("")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setFormData({
          ...formData,
          productImage: reader.result as string,
        })
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (
      !formData.productName ||
      !formData.productCode ||
      !formData.category ||
      !formData.subcategory ||
      !formData.price
    ) {
      setError("Please fill in all required fields")
      return
    }

    const newProduct: Product = {
      id: `prod-${Date.now()}`,
      sellerId: seller.id,
      sellerName: seller.name,
      shopName: seller.shopName,
      productCode: formData.productCode,
      productName: formData.productName,
      productImage: formData.productImage || "/diverse-products-still-life.png",
      category: formData.category,
      subcategory: formData.subcategory,
      price: Number.parseFloat(formData.price),
      description: formData.description,
      createdAt: new Date().toISOString(),
    }

    storage.saveProduct(newProduct)
    setFormData({
      productName: "",
      productCode: "",
      category: "",
      subcategory: "",
      price: "",
      description: "",
      productImage: "",
    })
    onProductAdded()
  }

  return (
    <div className="bg-gray-50 p-8 rounded-lg mb-8">
      <h2 className="text-2xl font-bold mb-6">Upload New Product</h2>

      {error && <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">{error}</div>}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">Product Name *</label>
            <input
              type="text"
              name="productName"
              value={formData.productName}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-black"
              placeholder="Product name"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Product Code *</label>
            <input
              type="text"
              name="productCode"
              value={formData.productCode}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-black"
              placeholder="e.g., ETH-001"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Category *</label>
            <select
              name="category"
              value={formData.category}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-black"
            >
              <option value="">Select category</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Subcategory *</label>
            <select
              name="subcategory"
              value={formData.subcategory}
              onChange={handleChange}
              disabled={!formData.category}
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-black disabled:bg-gray-200"
            >
              <option value="">Select subcategory</option>
              {formData.category &&
                subcategories[formData.category]?.map((subcat) => (
                  <option key={subcat} value={subcat}>
                    {subcat}
                  </option>
                ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Price (₹) *</label>
            <input
              type="number"
              name="price"
              value={formData.price}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-black"
              placeholder="0"
              min="0"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Product Image</label>
            <input
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-black"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Description</label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-black"
            placeholder="Product description"
            rows={4}
          />
        </div>

        <button
          type="submit"
          className="bg-black text-white px-6 py-3 rounded font-semibold hover:bg-gray-800 transition"
        >
          Upload Product
        </button>
      </form>
    </div>
  )
}
