"use client"

import { useRouter } from "next/navigation"
import type { Product } from "@/lib/types"

interface ProductCardProps {
  product: Product
  isSeller: boolean
  isSaved?: boolean
  onSave?: () => void
  onDelete?: () => void
}

export default function ProductCard({ product, isSeller, isSaved, onSave, onDelete }: ProductCardProps) {
  const router = useRouter()

  return (
    <div className="bg-white border border-gray-300 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition">
      <div className="relative">
        <img
          src={product.productImage || "/placeholder.svg"}
          alt={product.productName}
          className="w-full h-64 object-cover"
        />
        {!isSeller && onSave && (
          <button
            onClick={onSave}
            className={`absolute top-3 right-3 p-2 rounded-full transition ${
              isSaved ? "bg-black text-white" : "bg-white text-black border border-gray-300 hover:bg-gray-100"
            }`}
          >
            ♥
          </button>
        )}
      </div>

      <div className="p-4">
        <div className="mb-2">
          <span className="text-xs bg-gray-200 text-gray-800 px-2 py-1 rounded">{product.category}</span>
          <span className="text-xs bg-gray-200 text-gray-800 px-2 py-1 rounded ml-2">{product.subcategory}</span>
        </div>

        <h3 className="font-bold text-lg mb-1">{product.productName}</h3>
        <p className="text-sm text-gray-600 mb-2">Code: {product.productCode}</p>
        <p className="text-sm text-gray-600 mb-3">{product.shopName}</p>

        {product.description && <p className="text-sm text-gray-700 mb-3 line-clamp-2">{product.description}</p>}

        <div className="flex justify-between items-center gap-2">
          <span className="text-2xl font-bold">₹{product.price}</span>
          <div className="flex gap-2">
            {!isSeller && (
              <button
                onClick={() => router.push(`/product/${product.id}`)}
                className="bg-black text-white px-4 py-2 rounded hover:bg-gray-800 transition text-sm"
              >
                View
              </button>
            )}
            {isSeller && onDelete && (
              <button
                onClick={onDelete}
                className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition text-sm"
              >
                Delete
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
