"use client"

import { visakhapatamShops } from "@/lib/seed-data"

export default function FeaturedShops() {
  return (
    <section className="py-16 px-4 bg-white">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-4xl font-bold mb-12 text-center">Featured Shops</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {visakhapatamShops.map((shop) => (
            <div key={shop.id} className="bg-gray-50 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition">
              <img
                src={shop.shopImage || "/placeholder.svg"}
                alt={shop.shopName}
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="font-bold text-lg mb-2">{shop.shopName}</h3>
                <p className="text-sm text-gray-600 mb-2">{shop.shopLocation}</p>
                <p className="text-xs text-gray-500">{shop.shopAddress}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
