"use client"

import Link from "next/link"

export default function HeroSection() {
  return (
    <section className="bg-gradient-to-r from-black to-gray-900 text-white py-20 px-4">
      <div className="max-w-7xl mx-auto text-center">
        <h1 className="text-5xl md:text-6xl font-bold mb-6 text-balance">Discover Local Fashion</h1>
        <p className="text-xl md:text-2xl text-gray-300 mb-8 text-balance">
          Connect with local sellers and find unique clothing from Visakhapatam
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            href="/buyer-login"
            className="bg-white text-black px-8 py-3 rounded font-semibold hover:bg-gray-200 transition"
          >
            Shop Now
          </Link>
          <Link
            href="/seller-login"
            className="bg-gray-700 text-white px-8 py-3 rounded font-semibold hover:bg-gray-600 transition"
          >
            Become a Seller
          </Link>
        </div>
      </div>
    </section>
  )
}
