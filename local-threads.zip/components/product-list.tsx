"use client"

import { useState } from "react"
import type { Product } from "@/lib/types"
import { storage } from "@/lib/storage"
import ProductCard from "./product-card"

interface ProductListProps {
  products: Product[]
  isSeller: boolean
  buyerId?: string
  onProductDeleted?: () => void
}

export default function ProductList({ products, isSeller, buyerId, onProductDeleted }: ProductListProps) {
  const [savedProducts, setSavedProducts] = useState<Set<string>>(
    buyerId ? new Set(storage.getSavedProducts(buyerId).map((p) => p.id)) : new Set(),
  )

  const handleSaveProduct = (productId: string) => {
    if (!buyerId) return

    if (savedProducts.has(productId)) {
      storage.removeSavedProduct(buyerId, productId)
      setSavedProducts((prev) => {
        const newSet = new Set(prev)
        newSet.delete(productId)
        return newSet
      })
    } else {
      storage.saveProductForBuyer(buyerId, productId)
      setSavedProducts((prev) => new Set(prev).add(productId))
    }
  }

  const handleDeleteProduct = (productId: string) => {
    if (confirm("Are you sure you want to delete this product?")) {
      storage.deleteProduct(productId)
      onProductDeleted?.()
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {products.map((product) => (
        <ProductCard
          key={product.id}
          product={product}
          isSeller={isSeller}
          isSaved={savedProducts.has(product.id)}
          onSave={() => handleSaveProduct(product.id)}
          onDelete={() => handleDeleteProduct(product.id)}
        />
      ))}
    </div>
  )
}
