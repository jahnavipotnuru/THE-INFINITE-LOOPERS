"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { storage } from "@/lib/storage"
import type { Product, Seller } from "@/lib/types"
import Navigation from "@/components/navigation"
import UploadProductForm from "@/components/upload-product-form"
import ProductList from "@/components/product-list"

export default function SellerDashboard() {
  const router = useRouter()
  const [seller, setSeller] = useState<Seller | null>(null)
  const [products, setProducts] = useState<Product[]>([])
  const [showUploadForm, setShowUploadForm] = useState(false)

  useEffect(() => {
    const currentUser = storage.getCurrentUser()
    if (!currentUser || currentUser.userType !== "seller") {
      router.push("/seller-login")
      return
    }
    setSeller(currentUser as Seller)
    loadProducts()
  }, [router])

  const loadProducts = () => {
    const currentUser = storage.getCurrentUser()
    if (currentUser) {
      const sellerProducts = storage.getProductsBySeller(currentUser.id)
      setProducts(sellerProducts)
    }
  }

  const handleProductAdded = () => {
    loadProducts()
    setShowUploadForm(false)
  }

  const handleProductDeleted = () => {
    loadProducts()
  }

  if (!seller) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>
  }

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Seller Dashboard</h1>
          <div className="bg-gray-50 p-6 rounded-lg">
            <h2 className="text-2xl font-bold mb-2">{seller.shopName}</h2>
            <p className="text-gray-600 mb-1">{seller.shopAddress}</p>
            <p className="text-gray-600">{seller.shopLocation}</p>
          </div>
        </div>

        <div className="mb-8">
          <button
            onClick={() => setShowUploadForm(!showUploadForm)}
            className="bg-black text-white px-6 py-3 rounded font-semibold hover:bg-gray-800 transition"
          >
            {showUploadForm ? "Cancel" : "Upload New Product"}
          </button>
        </div>

        {showUploadForm && <UploadProductForm seller={seller} onProductAdded={handleProductAdded} />}

        <div>
          <h2 className="text-2xl font-bold mb-6">Your Products ({products.length})</h2>
          {products.length === 0 ? (
            <div className="bg-gray-50 p-8 rounded-lg text-center">
              <p className="text-gray-600">No products uploaded yet. Start by uploading your first product!</p>
            </div>
          ) : (
            <ProductList products={products} isSeller={true} onProductDeleted={handleProductDeleted} />
          )}
        </div>
      </div>
    </div>
  )
}
