"use client"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import { storage } from "@/lib/storage"
import type { Product, User } from "@/lib/types"
import Navigation from "@/components/navigation"
import { MapPin, MapIcon } from "lucide-react"

export default function ProductDetail() {
  const router = useRouter()
  const params = useParams()
  const productId = params.id as string
  const [product, setProduct] = useState<Product | null>(null)
  const [buyer, setBuyer] = useState<User | null>(null)
  const [isSaved, setIsSaved] = useState(false)
  const [showMap, setShowMap] = useState(false)

  useEffect(() => {
    const currentUser = storage.getCurrentUser()
    if (!currentUser || currentUser.userType !== "buyer") {
      router.push("/buyer-login")
      return
    }
    setBuyer(currentUser)

    const prod = storage.getProductById(productId)
    if (!prod) {
      router.push("/buyer-dashboard")
      return
    }
    setProduct(prod)
    setIsSaved(storage.isProductSaved(currentUser.id, productId))
  }, [productId, router])

  const handleSaveProduct = () => {
    if (!buyer || !product) return

    if (isSaved) {
      storage.removeSavedProduct(buyer.id, product.id)
      setIsSaved(false)
    } else {
      storage.saveProductForBuyer(buyer.id, product.id)
      setIsSaved(true)
    }
  }

  if (!product || !buyer) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>
  }

  const mapsEmbedUrl = `https://www.google.com/maps/embed/v1/place?key=AIzaSyDummyKey&q=${encodeURIComponent(product.shopLocation + ", Visakhapatam")}`

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <div className="max-w-6xl mx-auto px-4 py-8">
        <button onClick={() => router.back()} className="text-black hover:text-gray-600 mb-6 font-semibold">
          ← Back
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Product Image */}
          <div>
            <img
              src={product.productImage || "/placeholder.svg"}
              alt={product.productName}
              className="w-full h-96 object-cover rounded-lg border border-gray-300"
            />
            <button
              onClick={handleSaveProduct}
              className={`w-full mt-4 py-3 rounded font-semibold transition ${
                isSaved ? "bg-black text-white hover:bg-gray-800" : "bg-gray-200 text-black hover:bg-gray-300"
              }`}
            >
              {isSaved ? "♥ Saved" : "♡ Save Product"}
            </button>
          </div>

          {/* Product Details */}
          <div>
            <div className="mb-6">
              <div className="flex gap-2 mb-4">
                <span className="text-xs bg-gray-200 text-gray-800 px-3 py-1 rounded">{product.category}</span>
                <span className="text-xs bg-gray-200 text-gray-800 px-3 py-1 rounded">{product.subcategory}</span>
              </div>
              <h1 className="text-4xl font-bold mb-2">{product.productName}</h1>
              <p className="text-gray-600 mb-4">Product Code: {product.productCode}</p>
            </div>

            <div className="mb-8 pb-8 border-b border-gray-300">
              <p className="text-5xl font-bold text-black">₹{product.price}</p>
            </div>

            {product.description && (
              <div className="mb-8">
                <h2 className="text-xl font-bold mb-3">Description</h2>
                <p className="text-gray-700 leading-relaxed">{product.description}</p>
              </div>
            )}

            {/* Shop Information */}
            <div className="bg-gray-50 p-6 rounded-lg mb-8">
              <h2 className="text-xl font-bold mb-4">Shop Information</h2>
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-gray-600">Shop Name</p>
                  <p className="font-semibold text-lg">{product.shopName}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Address</p>
                  <p className="font-semibold">{product.shopAddress}</p>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin size={20} />
                  <div>
                    <p className="text-sm text-gray-600">Location</p>
                    <p className="font-semibold">{product.shopLocation}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* View on Map Button */}
            <button
              onClick={() => setShowMap(!showMap)}
              className="w-full bg-black text-white py-3 rounded font-semibold hover:bg-gray-800 transition flex items-center justify-center gap-2"
            >
              <MapIcon size={20} />
              {showMap ? "Hide Map" : "View Shop on Map"}
            </button>
          </div>
        </div>

        {/* Map Section */}
        {showMap && (
          <div className="mt-12 pt-8 border-t border-gray-300">
            <h2 className="text-2xl font-bold mb-6">Shop Location</h2>
            <div className="bg-gray-100 rounded-lg overflow-hidden border border-gray-300">
              <iframe
                width="100%"
                height="500"
                style={{ border: 0 }}
                loading="lazy"
                allowFullScreen
                referrerPolicy="no-referrer-when-downgrade"
                src={`https://www.google.com/maps/embed/v1/place?key=AIzaSyDummyKey&q=${encodeURIComponent(product.shopLocation + ", Visakhapatam, India")}`}
              ></iframe>
            </div>
            <p className="text-sm text-gray-600 mt-4">📍 {product.shopLocation}, Visakhapatam, India</p>
          </div>
        )}
      </div>
    </div>
  )
}
