"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { storage } from "@/lib/storage"
import type { Product, User } from "@/lib/types"
import Navigation from "@/components/navigation"
import ProductFilters from "@/components/product-filters"
import ProductList from "@/components/product-list"

export default function BuyerDashboard() {
  const router = useRouter()
  const [buyer, setBuyer] = useState<User | null>(null)
  const [allProducts, setAllProducts] = useState<Product[]>([])
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([])
  const [activeTab, setActiveTab] = useState<"browse" | "saved">("browse")
  const [filters, setFilters] = useState({
    category: "",
    subcategory: "",
    priceRange: [0, 5000],
    searchTerm: "",
  })

  useEffect(() => {
    const currentUser = storage.getCurrentUser()
    if (!currentUser || currentUser.userType !== "buyer") {
      router.push("/buyer-login")
      return
    }
    setBuyer(currentUser)
    loadProducts()
  }, [router])

  const loadProducts = () => {
    const products = storage.getProducts()
    setAllProducts(products)
    applyFilters(products, filters)
  }

  const applyFilters = (products: Product[], currentFilters: typeof filters) => {
    let filtered = products

    if (currentFilters.category) {
      filtered = filtered.filter((p) => p.category === currentFilters.category)
    }

    if (currentFilters.subcategory) {
      filtered = filtered.filter((p) => p.subcategory === currentFilters.subcategory)
    }

    filtered = filtered.filter(
      (p) => p.price >= currentFilters.priceRange[0] && p.price <= currentFilters.priceRange[1],
    )

    if (currentFilters.searchTerm) {
      const term = currentFilters.searchTerm.toLowerCase()
      filtered = filtered.filter(
        (p) =>
          p.productName.toLowerCase().includes(term) ||
          p.shopName.toLowerCase().includes(term) ||
          p.productCode.toLowerCase().includes(term),
      )
    }

    setFilteredProducts(filtered)
  }

  const handleFilterChange = (newFilters: typeof filters) => {
    setFilters(newFilters)
    applyFilters(allProducts, newFilters)
  }

  const getSavedProducts = () => {
    if (!buyer) return []
    return storage.getSavedProducts(buyer.id)
  }

  if (!buyer) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>
  }

  const displayProducts = activeTab === "browse" ? filteredProducts : getSavedProducts()

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8">Welcome, {buyer.name}!</h1>

        <div className="flex gap-4 mb-8 border-b border-gray-300">
          <button
            onClick={() => setActiveTab("browse")}
            className={`px-6 py-3 font-semibold transition ${
              activeTab === "browse" ? "border-b-2 border-black text-black" : "text-gray-600 hover:text-black"
            }`}
          >
            Browse Products
          </button>
          <button
            onClick={() => setActiveTab("saved")}
            className={`px-6 py-3 font-semibold transition ${
              activeTab === "saved" ? "border-b-2 border-black text-black" : "text-gray-600 hover:text-black"
            }`}
          >
            Saved Products ({getSavedProducts().length})
          </button>
        </div>

        {activeTab === "browse" && (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            <div className="lg:col-span-1">
              <ProductFilters onFilterChange={handleFilterChange} />
            </div>
            <div className="lg:col-span-3">
              {filteredProducts.length === 0 ? (
                <div className="bg-gray-50 p-8 rounded-lg text-center">
                  <p className="text-gray-600">No products found matching your filters.</p>
                </div>
              ) : (
                <ProductList products={filteredProducts} isSeller={false} buyerId={buyer.id} />
              )}
            </div>
          </div>
        )}

        {activeTab === "saved" && (
          <div>
            {displayProducts.length === 0 ? (
              <div className="bg-gray-50 p-8 rounded-lg text-center">
                <p className="text-gray-600">You haven't saved any products yet.</p>
              </div>
            ) : (
              <ProductList products={displayProducts} isSeller={false} buyerId={buyer.id} />
            )}
          </div>
        )}
      </div>
    </div>
  )
}
