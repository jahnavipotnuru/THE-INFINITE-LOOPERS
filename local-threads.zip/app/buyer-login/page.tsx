"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { storage } from "@/lib/storage"
import Navigation from "@/components/navigation"

export default function BuyerLogin() {
  const router = useRouter()
  const [isLogin, setIsLogin] = useState(true)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
  })
  const [error, setError] = useState("")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (isLogin) {
      const user = formData.email ? storage.getUserByEmail(formData.email) : storage.getUserByPhone(formData.phone)

      if (!user || user.userType !== "buyer") {
        setError("Invalid credentials or not a buyer account")
        return
      }

      storage.setCurrentUser(user)
      router.push("/buyer-dashboard")
    } else {
      if (!formData.name || (!formData.email && !formData.phone)) {
        setError("Please fill in all required fields")
        return
      }

      if (formData.email && storage.getUserByEmail(formData.email)) {
        setError("Email already registered")
        return
      }

      if (formData.phone && storage.getUserByPhone(formData.phone)) {
        setError("Phone already registered")
        return
      }

      const newUser = {
        id: `buyer-${Date.now()}`,
        name: formData.name,
        email: formData.email || undefined,
        phone: formData.phone || undefined,
        userType: "buyer" as const,
        createdAt: new Date().toISOString(),
      }

      storage.saveUser(newUser)
      storage.setCurrentUser(newUser)
      router.push("/buyer-dashboard")
    }
  }

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <div className="flex items-center justify-center min-h-[calc(100vh-64px)] px-4">
        <div className="w-full max-w-md bg-gray-50 rounded-lg shadow-lg p-8">
          <h1 className="text-3xl font-bold mb-2 text-center">{isLogin ? "Buyer Login" : "Buyer Registration"}</h1>
          <p className="text-center text-gray-600 mb-6">
            {isLogin ? "Sign in to your account" : "Create a new account"}
          </p>

          {error && <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">{error}</div>}

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div>
                <label className="block text-sm font-medium mb-1">Full Name</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-black"
                  placeholder="Your name"
                />
              </div>
            )}

            <div>
              <label className="block text-sm font-medium mb-1">Email</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-black"
                placeholder="your@email.com"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Phone Number</label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-black"
                placeholder="+91 XXXXXXXXXX"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-black text-white py-2 rounded font-semibold hover:bg-gray-800 transition"
            >
              {isLogin ? "Sign In" : "Create Account"}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-600">
              {isLogin ? "Don't have an account?" : "Already have an account?"}
              <button
                onClick={() => {
                  setIsLogin(!isLogin)
                  setError("")
                  setFormData({ name: "", email: "", phone: "", password: "" })
                }}
                className="text-black font-semibold hover:underline ml-1"
              >
                {isLogin ? "Register" : "Login"}
              </button>
            </p>
          </div>

          <div className="mt-4 text-center">
            <p className="text-gray-600">
              Are you a seller?
              <Link href="/seller-login" className="text-black font-semibold hover:underline ml-1">
                Seller Login
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
