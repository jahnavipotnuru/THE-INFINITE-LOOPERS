"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { storage } from "@/lib/storage"
import Navigation from "@/components/navigation"

export default function SellerLogin() {
  const router = useRouter()
  const [isLogin, setIsLogin] = useState(true)
  const [formData, setFormData] = useState({
    name: "",
    shopName: "",
    shopAddress: "",
    shopLocation: "",
    email: "",
    phone: "",
    password: "",
  })
  const [error, setError] = useState("")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (isLogin) {
      const user = formData.email ? storage.getUserByEmail(formData.email) : storage.getUserByPhone(formData.phone)

      if (!user || user.userType !== "seller") {
        setError("Invalid credentials or not a seller account")
        return
      }

      storage.setCurrentUser(user)
      router.push("/seller-dashboard")
    } else {
      if (
        !formData.name ||
        !formData.shopName ||
        !formData.shopAddress ||
        !formData.shopLocation ||
        (!formData.email && !formData.phone)
      ) {
        setError("Please fill in all required fields")
        return
      }

      if (formData.email && storage.getUserByEmail(formData.email)) {
        setError("Email already registered")
        return
      }

      if (formData.phone && storage.getUserByPhone(formData.phone)) {
        setError("Phone already registered")
        return
      }

      const newSeller = {
        id: `seller-${Date.now()}`,
        name: formData.name,
        shopName: formData.shopName,
        shopAddress: formData.shopAddress,
        shopLocation: formData.shopLocation,
        email: formData.email || undefined,
        phone: formData.phone || undefined,
        userType: "seller" as const,
        createdAt: new Date().toISOString(),
      }

      storage.saveUser(newSeller)
      storage.setCurrentUser(newSeller)
      router.push("/seller-dashboard")
    }
  }

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <div className="flex items-center justify-center min-h-[calc(100vh-64px)] px-4 py-8">
        <div className="w-full max-w-md bg-gray-50 rounded-lg shadow-lg p-8">
          <h1 className="text-3xl font-bold mb-2 text-center">{isLogin ? "Seller Login" : "Seller Registration"}</h1>
          <p className="text-center text-gray-600 mb-6">
            {isLogin ? "Sign in to your seller account" : "Register your shop"}
          </p>

          {error && <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">{error}</div>}

          <form onSubmit={handleSubmit} className="space-y-4 max-h-96 overflow-y-auto">
            {!isLogin && (
              <>
                <div>
                  <label className="block text-sm font-medium mb-1">Your Name</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-black"
                    placeholder="Your name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Shop Name</label>
                  <input
                    type="text"
                    name="shopName"
                    value={formData.shopName}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-black"
                    placeholder="Your shop name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Shop Address</label>
                  <input
                    type="text"
                    name="shopAddress"
                    value={formData.shopAddress}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-black"
                    placeholder="Shop address"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Shop Location</label>
                  <input
                    type="text"
                    name="shopLocation"
                    value={formData.shopLocation}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-black"
                    placeholder="Area/Location"
                  />
                </div>
              </>
            )}

            <div>
              <label className="block text-sm font-medium mb-1">Email</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-black"
                placeholder="your@email.com"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Phone Number</label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-black"
                placeholder="+91 XXXXXXXXXX"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-black text-white py-2 rounded font-semibold hover:bg-gray-800 transition"
            >
              {isLogin ? "Sign In" : "Register Shop"}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-600">
              {isLogin ? "Don't have an account?" : "Already have an account?"}
              <button
                onClick={() => {
                  setIsLogin(!isLogin)
                  setError("")
                  setFormData({
                    name: "",
                    shopName: "",
                    shopAddress: "",
                    shopLocation: "",
                    email: "",
                    phone: "",
                    password: "",
                  })
                }}
                className="text-black font-semibold hover:underline ml-1"
              >
                {isLogin ? "Register" : "Login"}
              </button>
            </p>
          </div>

          <div className="mt-4 text-center">
            <p className="text-gray-600">
              Are you a buyer?
              <Link href="/buyer-login" className="text-black font-semibold hover:underline ml-1">
                Buyer Login
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
