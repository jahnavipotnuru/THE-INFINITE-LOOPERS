"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { initializeSeedData } from "@/lib/seed-data"
import Navigation from "@/components/navigation"
import HeroSection from "@/components/hero-section"
import FeaturedShops from "@/components/featured-shops"
import Footer from "@/components/footer"

export default function Home() {
  const router = useRouter()
  const [isInitialized, setIsInitialized] = useState(false)

  useEffect(() => {
    initializeSeedData()
    setIsInitialized(true)
  }, [])

  if (!isInitialized) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>
  }

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <HeroSection />
      <FeaturedShops />
      <Footer />
    </div>
  )
}
